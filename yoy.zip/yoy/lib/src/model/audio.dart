class AUDIO {
  final String? url;
  AUDIO({this.url});
}
