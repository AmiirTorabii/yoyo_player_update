class M3U8pass {
  final String? dataQuality;
  final String? dataURL;
  M3U8pass({this.dataURL, this.dataQuality});
}
