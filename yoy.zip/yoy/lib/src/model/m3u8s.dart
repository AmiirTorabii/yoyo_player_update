import 'package:yoyo_player/src/model/m3u8.dart';

class M3U8s {
  final List<M3U8pass>? m3u8s;

  M3U8s({this.m3u8s});
}
