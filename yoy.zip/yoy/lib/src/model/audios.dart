import 'audio.dart';

class AUDIOs {
  final List<AUDIO>? dataaudios;
  AUDIOs({this.dataaudios});
}
