## [0.0.1] - 2020-07-30

* M3U8 can be turned on by selecting the quality

## [0.0.2] - 2020-08-04

* Bug Fix
* FullScreen Add

## [0.0.3] - 2020-08-04

* Bug Fix

## [0.0.4] - 2020-08-05

* Bug Fix

## [0.0.5] - 2020-08-06

* Bug Fix
* (.srt) Video Subtitle Support

## [0.0.6] - 2020-08-07

* Bug Fix
* Custom Vieo Play Widget Support

## [0.0.7] - 2020-08-07

* analysis fix

## [0.0.8] - 2020-08-12

* FullScreen Support
* Fix quality issues

## [0.0.9] - 2020-09-17

* change ui
* fix audio streaming
* remove sub support
* Bug fix

## [0.1.0] - 2020-10-19

* dependencies update
